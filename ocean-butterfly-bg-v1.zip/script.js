const bubbleWrap = document.getElementById("bubbles");

for (let i = 0; i < 42; i++) {
  const bubble = document.createElement("span");
  bubble.className = "bubble";
  bubble.style.setProperty("--left", `${Math.random() * 100}%`);
  bubble.style.setProperty("--size", `${Math.random() * 20 + 4}px`);
  bubble.style.setProperty("--duration", `${Math.random() * 12 + 12}s`);
  bubble.style.setProperty("--delay", `${Math.random() * -22}s`);
  bubbleWrap.appendChild(bubble);
}
